<?php

Class ControladorPlantilla{
    public function ctrGetplantilla(){
        include "vistas/plantilla.php";
    }

}